---------------
  Colaris.exe
----------------
This trojan is skidded :)
Skidding forever :D
Made in C++
Creation date: April 30 2024
Malware name: Dolaris
Damage rate: Destructive



























Hi fr4ctalz, pankoza, I am Wynn, 2009YCTG, yedb0y33k & N17Pro3426